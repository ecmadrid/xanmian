/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QVBoxLayout *verticalLayout;
    QStackedWidget *stackedWidget;
    QWidget *pageAccept;
    QVBoxLayout *verticalLayout_4;
    QLabel *labelAccept;
    QWidget *pageDownload;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_3;
    QLabel *labelDownload;
    QProgressBar *progressBar;
    QGridLayout *buttonBar;
    QPushButton *buttonCancel;
    QPushButton *buttonOk;
    QSpacerItem *horizontalSpacer2;
    QLabel *label;
    QPushButton *buttonAbout;
    QSpacerItem *horizontalSpacer1;
    QPushButton *buttonHelp;

    void setupUi(QDialog *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(522, 297);
        verticalLayout = new QVBoxLayout(MainWindow);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        stackedWidget = new QStackedWidget(MainWindow);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        pageAccept = new QWidget();
        pageAccept->setObjectName(QString::fromUtf8("pageAccept"));
        verticalLayout_4 = new QVBoxLayout(pageAccept);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        labelAccept = new QLabel(pageAccept);
        labelAccept->setObjectName(QString::fromUtf8("labelAccept"));
        labelAccept->setTextFormat(Qt::RichText);
        labelAccept->setWordWrap(true);

        verticalLayout_4->addWidget(labelAccept);

        stackedWidget->addWidget(pageAccept);
        pageDownload = new QWidget();
        pageDownload->setObjectName(QString::fromUtf8("pageDownload"));
        verticalLayout_2 = new QVBoxLayout(pageDownload);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        groupBox = new QGroupBox(pageDownload);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        verticalLayout_3 = new QVBoxLayout(groupBox);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        labelDownload = new QLabel(groupBox);
        labelDownload->setObjectName(QString::fromUtf8("labelDownload"));
        labelDownload->setWordWrap(true);

        verticalLayout_3->addWidget(labelDownload);


        verticalLayout_2->addWidget(groupBox);

        progressBar = new QProgressBar(pageDownload);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setValue(24);

        verticalLayout_2->addWidget(progressBar);

        stackedWidget->addWidget(pageDownload);

        verticalLayout->addWidget(stackedWidget);

        buttonBar = new QGridLayout();
        buttonBar->setSpacing(5);
        buttonBar->setObjectName(QString::fromUtf8("buttonBar"));
        buttonBar->setSizeConstraint(QLayout::SetDefaultConstraint);
        buttonBar->setContentsMargins(0, 0, 0, 0);
        buttonCancel = new QPushButton(MainWindow);
        buttonCancel->setObjectName(QString::fromUtf8("buttonCancel"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(buttonCancel->sizePolicy().hasHeightForWidth());
        buttonCancel->setSizePolicy(sizePolicy);
        QIcon icon;
        QString iconThemeName = QString::fromUtf8("window-close");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon = QIcon::fromTheme(iconThemeName);
        } else {
            icon.addFile(QString::fromUtf8("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        buttonCancel->setIcon(icon);
        buttonCancel->setAutoDefault(true);

        buttonBar->addWidget(buttonCancel, 0, 8, 1, 1);

        buttonOk = new QPushButton(MainWindow);
        buttonOk->setObjectName(QString::fromUtf8("buttonOk"));
        sizePolicy.setHeightForWidth(buttonOk->sizePolicy().hasHeightForWidth());
        buttonOk->setSizePolicy(sizePolicy);
        QIcon icon1;
        iconThemeName = QString::fromUtf8("dialog-ok");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon1 = QIcon::fromTheme(iconThemeName);
        } else {
            icon1.addFile(QString::fromUtf8("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        buttonOk->setIcon(icon1);
        buttonOk->setAutoDefault(true);

        buttonBar->addWidget(buttonOk, 0, 6, 1, 1);

        horizontalSpacer2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        buttonBar->addItem(horizontalSpacer2, 0, 5, 1, 1);

        label = new QLabel(MainWindow);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMaximumSize(QSize(32, 32));
        label->setMidLineWidth(0);
        label->setPixmap(QPixmap(QString::fromUtf8(":/icons/logo.svg")));
        label->setScaledContents(true);

        buttonBar->addWidget(label, 0, 3, 1, 1);

        buttonAbout = new QPushButton(MainWindow);
        buttonAbout->setObjectName(QString::fromUtf8("buttonAbout"));
        sizePolicy.setHeightForWidth(buttonAbout->sizePolicy().hasHeightForWidth());
        buttonAbout->setSizePolicy(sizePolicy);
        QIcon icon2;
        iconThemeName = QString::fromUtf8("help-about");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon2 = QIcon::fromTheme(iconThemeName);
        } else {
            icon2.addFile(QString::fromUtf8("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        buttonAbout->setIcon(icon2);
        buttonAbout->setAutoDefault(true);

        buttonBar->addWidget(buttonAbout, 0, 0, 1, 1);

        horizontalSpacer1 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        buttonBar->addItem(horizontalSpacer1, 0, 2, 1, 1);

        buttonHelp = new QPushButton(MainWindow);
        buttonHelp->setObjectName(QString::fromUtf8("buttonHelp"));
        sizePolicy.setHeightForWidth(buttonHelp->sizePolicy().hasHeightForWidth());
        buttonHelp->setSizePolicy(sizePolicy);
        QIcon icon3;
        iconThemeName = QString::fromUtf8("help-contents");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon3 = QIcon::fromTheme(iconThemeName);
        } else {
            icon3.addFile(QString::fromUtf8("."), QSize(), QIcon::Normal, QIcon::Off);
        }
        buttonHelp->setIcon(icon3);
        buttonHelp->setAutoDefault(true);

        buttonBar->addWidget(buttonHelp, 0, 1, 1, 1);


        verticalLayout->addLayout(buttonBar);


        retranslateUi(MainWindow);
        QObject::connect(buttonCancel, SIGNAL(pressed()), MainWindow, SLOT(reject()));

        stackedWidget->setCurrentIndex(0);
        buttonCancel->setDefault(true);
        buttonOk->setDefault(false);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QDialog *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Codecs Installer", nullptr));
        labelAccept->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"justify\">This application allows you to install restricted codecs that permit advanced video and audio functions.</p><p align=\"justify\">In some jurisdictions, their distribution may be limited. Please check the regulations in your area. </p><p align=\"justify\"><br/></p><p align=\"justify\"><span style=\" font-weight:600;\">Do you assume legal responsibility for downloading these codecs?</span></p></body></html>", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainWindow", "Downloading codecs files", nullptr));
        labelDownload->setText(QString());
#if QT_CONFIG(tooltip)
        buttonCancel->setToolTip(QCoreApplication::translate("MainWindow", "Cancel any changes then quit", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonCancel->setText(QCoreApplication::translate("MainWindow", "Cancel", nullptr));
#if QT_CONFIG(shortcut)
        buttonCancel->setShortcut(QCoreApplication::translate("MainWindow", "Alt+N", nullptr));
#endif // QT_CONFIG(shortcut)
#if QT_CONFIG(tooltip)
        buttonOk->setToolTip(QCoreApplication::translate("MainWindow", "Begin codec download and installation", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonOk->setText(QCoreApplication::translate("MainWindow", "OK", nullptr));
#if QT_CONFIG(shortcut)
        buttonOk->setShortcut(QString());
#endif // QT_CONFIG(shortcut)
        label->setText(QString());
#if QT_CONFIG(tooltip)
        buttonAbout->setToolTip(QCoreApplication::translate("MainWindow", "About this application", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonAbout->setText(QCoreApplication::translate("MainWindow", "About...", nullptr));
#if QT_CONFIG(shortcut)
        buttonAbout->setShortcut(QCoreApplication::translate("MainWindow", "Alt+B", nullptr));
#endif // QT_CONFIG(shortcut)
#if QT_CONFIG(tooltip)
        buttonHelp->setToolTip(QCoreApplication::translate("MainWindow", "Display help ", nullptr));
#endif // QT_CONFIG(tooltip)
        buttonHelp->setText(QCoreApplication::translate("MainWindow", "Help", nullptr));
#if QT_CONFIG(shortcut)
        buttonHelp->setShortcut(QCoreApplication::translate("MainWindow", "Alt+H", nullptr));
#endif // QT_CONFIG(shortcut)
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
