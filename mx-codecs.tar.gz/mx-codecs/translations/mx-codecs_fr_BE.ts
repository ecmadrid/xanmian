<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.0" language="fr_BE">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>Codecs Installer</source>
        <translation>Installateur de Codecs</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="27"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;This application allows you to install restricted codecs that permit advanced video and audio functions.&lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;In some jurisdictions, their distribution may be limited. Please check the regulations in your area. &lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;&lt;br/&gt;&lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Do you assume legal responsibility for downloading these codecs?&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;justify&quot;&gt;Cette application vous permet d’installer des codecs non libres permettant des fonctions audio et vidéo avancées.&lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;Dans certaines juridictions, leur distribution doit être limitée afin que l’utilisateur puisse respecter les réglementations locales. &lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;&lt;br/&gt;&lt;/p&gt;&lt;p align=&quot;justify&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Êtes-vous prêt à assumer la responsabilité juridique du téléchargement de ces codecs?&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="44"/>
        <source>Downloading codecs files</source>
        <translation>Téléchargement des fichiers codecs</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="94"/>
        <source>Cancel any changes then quit</source>
        <translation>Annuler toutes les modifications puis quitter</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="97"/>
        <location filename="../mainwindow.cpp" line="268"/>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="104"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="117"/>
        <source>Begin codec download and installation</source>
        <translation>Démarrer le téléchargement et l’installation du codec</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="120"/>
        <source>OK</source>
        <translation>Valider</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="175"/>
        <source>About this application</source>
        <translation>À propos de cette application</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="178"/>
        <source>About...</source>
        <translation>À propos ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="185"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="214"/>
        <source>Display help </source>
        <translation>Afficher l’aide </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="217"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="224"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="105"/>
        <location filename="../mainwindow.cpp" line="112"/>
        <location filename="../mainwindow.cpp" line="120"/>
        <location filename="../mainwindow.cpp" line="128"/>
        <location filename="../mainwindow.cpp" line="137"/>
        <location filename="../mainwindow.cpp" line="144"/>
        <location filename="../mainwindow.cpp" line="153"/>
        <location filename="../mainwindow.cpp" line="161"/>
        <source>&lt;b&gt;Running command...&lt;/b&gt;&lt;p&gt;</source>
        <translation>&lt;b&gt;Commande en cours d’exécution ...&lt;/b&gt;&lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="108"/>
        <location filename="../mainwindow.cpp" line="124"/>
        <location filename="../mainwindow.cpp" line="131"/>
        <location filename="../mainwindow.cpp" line="140"/>
        <location filename="../mainwindow.cpp" line="146"/>
        <location filename="../mainwindow.cpp" line="157"/>
        <location filename="../mainwindow.cpp" line="164"/>
        <location filename="../mainwindow.cpp" line="193"/>
        <location filename="../mainwindow.cpp" line="246"/>
        <source>Error</source>
        <translation>Erreur</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="109"/>
        <location filename="../mainwindow.cpp" line="125"/>
        <location filename="../mainwindow.cpp" line="141"/>
        <location filename="../mainwindow.cpp" line="158"/>
        <source>Cannot connect to the download site</source>
        <translation>Vous ne pouvez pas vous connecter au site de téléchargement</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="115"/>
        <location filename="../mainwindow.cpp" line="132"/>
        <location filename="../mainwindow.cpp" line="147"/>
        <location filename="../mainwindow.cpp" line="165"/>
        <source>Error downloading %1</source>
        <translation>Erreur en téléchargeant %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="170"/>
        <source>&lt;b&gt;Download Finished.&lt;/b&gt;</source>
        <translation>&lt;b&gt;Téléchargement Terminé.&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="189"/>
        <source>Installing downloaded files</source>
        <translation>Installation des fichiers téléchargés</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="194"/>
        <source>No downloaded *.debs files found.</source>
        <translation>Aucun fichier *. debs trouvé.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="207"/>
        <source>&lt;b&gt;Installing...&lt;/b&gt;&lt;p&gt;</source>
        <translation>&lt;b&gt;Installation ...&lt;/b&gt;&lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="220"/>
        <source>Error installing %1</source>
        <translation>Erreur lors de l’installation de %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="224"/>
        <source>Fix missing dependencies...</source>
        <translation>Réparation des dépendances manquantes ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="226"/>
        <source>Error running %1 command</source>
        <translation>Erreur lors de l’activation de la commande %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="238"/>
        <source>&lt;b&gt;Installation process has finished&lt;/b&gt;</source>
        <translation>&lt;b&gt;Le processus d’installation est terminé&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="242"/>
        <source>Finished</source>
        <translation>Terminé</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="243"/>
        <source>Codecs files have been downloaded and installed successfully.</source>
        <translation>les fichiers Codecs ont été téléchargés et installés avec succès.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="247"/>
        <source>Process finished. Errors have occurred during the installation.</source>
        <translation>Processus terminé. Des erreurs se sont produites lors de l’installation.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="261"/>
        <source>About Codecs</source>
        <translation>À propos de Codecs</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="262"/>
        <source>Codecs</source>
        <translation>Codecs</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="262"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="264"/>
        <source>Simple codecs downloader for Linux</source>
        <translation>Simple gestionnaire de téléchargement de codecs pour Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="265"/>
        <source>Copyright (c) Linux</source>
        <translation>Copyright (c) Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="266"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="267"/>
        <location filename="../mainwindow.cpp" line="277"/>
        <source>Changelog</source>
        <translation>Journal des modifications</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="285"/>
        <source>&amp;Close</source>
        <translation>&amp;Quitter</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="53"/>
        <source>Unable to get exclusive lock</source>
        <translation>Impossible d’obtenir le verrou exclusif</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="54"/>
        <source>Another package management application (like Synaptic or apt-get), is already running. Please close that application first</source>
        <translation>Une autre application de gestion des paquets (comme Synaptic ou apt-get) est déjà en cours d’exécution. Veuillez d’abord fermer cette application.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="67"/>
        <source>You must run this program as root.</source>
        <translation>Vous devez exécuter cette application en tant qu’administrateur.</translation>
    </message>
</context>
</TS>