mx-codecs
=========

tool for installing restricted deb files.

Post MX-14 build

This repo will be archived. We are not planning to use this program in future releases, all codecs can be installed through Synaptic or mx-packageinstaller
