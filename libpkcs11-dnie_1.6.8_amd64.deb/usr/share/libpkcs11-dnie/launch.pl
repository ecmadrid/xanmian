#!/usr/bin/perl


system("killall firefox");

#if (-e "/usr/bin/firefox") {
#  system("/usr/bin/firefox /usr/share/libpkcs11-dnie/launch.html &");
#} elsif (-e "/usr/local/bin/firefox") {
#  system("/usr/local/bin/firefox /usr/share/libpkcs11-dnie/launch.html &");
#}

my $user = getlogin();

system("sudo -u $user firefox /usr/share/libpkcs11-dnie/launch.html &");

exit(0);
